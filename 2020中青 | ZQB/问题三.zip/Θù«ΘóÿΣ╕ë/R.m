function f=R(x) 
load('ping_jun_shou_yi_lv.mat')
a=ping_jun_shou_yi_lv;
f=-(a(1)*x(1)+a(2)*x(2)+a(3)*x(3)+a(4)*x(4)+a(5)*x(5)+a(6)*x(6)+a(7)*x(7)+a(8)*x(8)+a(9)*x(9)+a(10)*x(10));
